# Classe + Template em LaTeX para formatação de monografias seguindo os padrões da Unifil.

Seguindo as modificações feitas pelo Rafael Shinohara, fiz mais algumas revisões no ano passado (2016) na classe e montei um template pronto para ser 
transformado em PDF (utilizando pdflatex).
