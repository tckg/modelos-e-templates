# Modelo LaTeX para artigos para a revista Terra e Cultura

Para quem utiliza LaTeX, este arquivo já está pré-configurado para gerar documentos corretamente formatados de acordo com as regras da Biblioteca da UniFil para artigos da Revista Terra e Cultura.

# Créditos

Agradecimentos ao aluno *Hugo Henrique Ribeiro dos Anjos* por compartilhar seu trabalho.
